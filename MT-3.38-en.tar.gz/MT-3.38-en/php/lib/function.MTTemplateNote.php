<?php
function smarty_function_MTTemplateNote($args, &$ctx) {
    return '';
}
?>
