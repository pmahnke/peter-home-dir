<?php
function translate_phrase($str, $params = null) {
    return translate_phrase_param($str, $params);
}
?>
