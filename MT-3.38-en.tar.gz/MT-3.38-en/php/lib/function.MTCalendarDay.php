<?php
function smarty_function_MTCalendarDay($args, &$ctx) {
    return $ctx->stash('CalendarDay');
}
?>
