<?php
function smarty_modifier_trim($text) {
    return trim($text);
}
?>