<?php
function smarty_modifier_ltrim($text) {
    return ltrim($text);
}
?>