# GoogleSearch plugin for Movable Type
# Author: Six Apart (http://www.sixapart.com)
# Released under the Artistic License
#
# $Id: en_us.pm 36 2006-06-13 16:17:15Z jallen $

package GoogleSearch::L10N::en_us;

use strict;

use base 'GoogleSearch::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
