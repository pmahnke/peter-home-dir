package StyleCatcher::L10N::en_us;

use strict;

use base 'StyleCatcher::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
