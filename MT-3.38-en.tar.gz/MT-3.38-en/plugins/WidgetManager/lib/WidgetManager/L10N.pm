# WidgetManager plugin for Movable Type
# Author: Byrne Reese, Six Apart (http://www.sixapart.com)
# Released under the Artistic License
#
# $Id: L10N.pm 29367 2006-05-20 04:42:10Z bchoate $

package WidgetManager::L10N;
use strict;
use base 'MT::Plugin::L10N';

1;
